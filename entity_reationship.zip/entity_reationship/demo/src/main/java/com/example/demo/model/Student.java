package com.example.demo.model;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class Student {
    @Id
    @Column(insertable=false, updatable=false)
    private int id;
    private String name,department,schools;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "id")
    private School school;
}