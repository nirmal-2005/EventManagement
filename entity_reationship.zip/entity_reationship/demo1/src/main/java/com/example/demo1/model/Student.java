package com.example.demo1.model;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class Student {
    @Id
    private int id;
    private String name,dept;
    @JsonBackReference
    @ManyToOne
    @JoinColumn(name = "sc_id")
    private School school;
}